package me.alpha432.oyvey.features.modules.render;


import me.alpha432.oyvey.features.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.Module;

public class BreakHighlight extends Module {

    public BreakHighlight() {
        super("BreakHighlight","",Category.RENDER,true,true,false);
    }

    public void onUpdate() {
    }


    @Override
    public void onRender2D(Render2DEvent event) {

    }
}
