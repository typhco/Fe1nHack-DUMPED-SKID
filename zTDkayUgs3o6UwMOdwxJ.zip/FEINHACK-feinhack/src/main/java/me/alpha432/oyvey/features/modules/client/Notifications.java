package me.alpha432.oyvey.features.modules.client;

import me.alpha432.oyvey.features.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.Module;

public class Notifications extends Module {

    public Notifications() {
        super("Notifications", "", Category.CLIENT, true, false, false);
    }

    @Override
    public void onRender2D(Render2DEvent event) {

    }
}
