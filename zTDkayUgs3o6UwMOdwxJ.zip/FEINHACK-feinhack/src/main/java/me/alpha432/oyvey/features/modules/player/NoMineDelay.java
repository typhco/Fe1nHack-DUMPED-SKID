package me.alpha432.oyvey.features.modules.player;

import me.alpha432.oyvey.features.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.Module;

public class NoMineDelay extends Module{

    public NoMineDelay() {
        super("NoMineDelay","",Category.PLAYER,true,false,true);
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        
    }
}
