package me.alpha432.oyvey.event.impl;

public class DisconnectEvent {
    public DisconnectEvent() {
    }
}
