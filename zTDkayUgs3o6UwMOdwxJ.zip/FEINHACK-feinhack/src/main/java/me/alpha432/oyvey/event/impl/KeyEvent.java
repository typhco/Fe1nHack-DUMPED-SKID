package me.alpha432.oyvey.event.impl;

import me.alpha432.oyvey.event.Event;

public class KeyEvent extends Event {
    private final int key;

    public KeyEvent(int key) {
        this.key = key;
    }

    public int getKey() {
        return key;
    }
}
