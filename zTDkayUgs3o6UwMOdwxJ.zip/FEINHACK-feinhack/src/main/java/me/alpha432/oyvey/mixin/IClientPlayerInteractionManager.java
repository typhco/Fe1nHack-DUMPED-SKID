package me.alpha432.oyvey.mixin;

public interface IClientPlayerInteractionManager {
    void meteor$syncSelected();
}
